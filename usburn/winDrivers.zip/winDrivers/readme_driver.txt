﻿Das sind die USB-Treiber.

Es gibt zwei unterschiedliche Versionen. 

Die eine (driver_98_me_2k_xp) ist ein erprobter älterer Treiber, der noch Windows98/me unterstützt und auch unter Windows2000 stabil läuft.

Die andere (driver_2k_xp_Vista) ist noch neu und unterstützt Windows2000, WindowsXP, Windows_Vista32 sowie Windows_Vista64. 

sprut
02.02.2008
