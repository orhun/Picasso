#!/bin/bash
#
# Simple Script to run usburnGUI as root in a console.
#
#
# Please insert your correct path to your usburnGUI executable!
# For example:
cd /opt/usburnGUI
#
# Run usburn GUI as root:
gksudo ./usburnGUI
#
# In case you cant run this scipt, you may need to set the execute-right.
# You can do this by typing:
# chmod +x /path/to/runusburn.sh
#
#
# If you want to start this Script with a link you can execute:
# gnome-terminal --command /path/to/runusburn.sh
#

